<?php
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';
require 'OAuth.php';




$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();
/*
Enable SMTP debugging
0 = off (for production use)
1 = client messages
2 = client and server messages
*/
$mail->SMTPDebug = 0;
$mail->Host = 'mail.marvemcenterexpress.com'; //servidor de correo
$mail->Port = 587; //puerto de correo
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "soporte@marvemcenterexpress.com"; //correo del hosting - donde llegan y envia los correos
$mail->Password = "L)5v#}Sf7#8t"; //contrase単a del correo de arriba
$mail->setFrom('soporte@marvemcenterexpress.com', 'Marvem Center Express'); //indica de donde se envia el correo
$mail->addAddress($correo_cliente, 'Aplicación'); // $correo_cli
$mail->Subject = 'Recuperación de Contraseña';
$mail->Body = "<div style='padding:5px;'> <br> <h2>RECUPERACIÓN DE CONTRASEÑA </h2><br><br>USUARIO: ".$usuario."  <br><br>  CONTRASEÑA: ".$clave." <br> <br>   <br> </div>";
//$mail->addAttachment('/levox2.png', 'My uploaded file'); <img src='/levox2.png' width='150' height='110'>
$mail->CharSet = 'UTF-8'; // Con esto ya funcionan los acentos
$mail->IsHTML(true);

if (!$mail->send())
{
	echo "Error al enviar el E-Mail: ".$mail->ErrorInfo;
}
else
{
	// header("Location:../../index.php");
}
?>
